__version__ = '2.5.2'
__git_version__ = '0.6.0-108196-g957590ea15c'
